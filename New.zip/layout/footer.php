 <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; 2017-2019 <a href="http://webinfoera.com" target="_blank">Webinfoera</a>.</strong> All rights
    reserved.
  </footer>